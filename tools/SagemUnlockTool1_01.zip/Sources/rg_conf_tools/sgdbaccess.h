int SG_DB_Open_ThreadSafe(int n0);
void SG_DB_Close_ThreadSafe(int nDB, int n0);

char* SG_DB_Get(int nDB, char* strPath);
int SG_DB_Set(int nDB, char* strPath, char* strValue);
int SG_DB_Delete(int nDB, char* strPath);

