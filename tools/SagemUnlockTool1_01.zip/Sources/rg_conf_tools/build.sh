#!/bin/sh
mips-linux-gcc rg_conf_set.c -L. -lopenrg -lrg_config -lcrypto -ljutil -lssl -lsgdbaccess -o rg_conf_set
mips-linux-gcc rg_conf_del.c -L. -lopenrg -lrg_config -lcrypto -ljutil -lssl -lsgdbaccess -o rg_conf_del
mips-linux-gcc telneten.c -L. -lopenrg -lrg_config -lcrypto -ljutil -lssl -lsgdbaccess -o telneten
