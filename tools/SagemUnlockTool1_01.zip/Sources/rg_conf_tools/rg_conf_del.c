//----------------------------------------------
//
//		rg_conf_del for SAGEM modems
//
//			Reverse engineered by sibisties
//			2013-04-13
//
//----------------------------------------------

#include <stdio.h>
#include "sgdbaccess.h"

int main(int argc, char *argv[])
{
	int nID;
	int nResult;

	if(argc!=2)
	{
		printf("Usage: %s <path>\r\n",argv[0]);
		nResult=1;
	}
	else if((nID=SG_DB_Open_ThreadSafe(0))==0)
	{
		puts("DB_Open failed!\r\n");
		nResult=2;
	}
	else
	{
		if((nResult=SG_DB_Delete(nID,argv[1]))!=0)
		{
			printf("DB_Delete failed! (%d)\r\n",nResult);
			nResult=3;
		}
		else
		{
			puts("OK!");
		}

		SG_DB_Close_ThreadSafe(nID,0);
	}

	return(nResult);
}
