#!/bin/sh

/tmp/unlock/telneten 0 5
killall stats

rm -rf /mnt/jffs2/p.tar
rm -rf /tmp/unlock
rm -rf /tmp/vdslcmd.out
rm -rf /home
ln -s /mnt/cramfs/home /home
