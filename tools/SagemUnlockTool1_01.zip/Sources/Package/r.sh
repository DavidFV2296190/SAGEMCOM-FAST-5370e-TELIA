#!/bin/sh

rm -rf /home
mkdir -p /home/httpd/html
ln -s /mnt/cramfs/home/httpd/html/* /home/httpd/html
ln -s /tmp/unlock /home/httpd/html/stats

if [ $1 = 1 ]; then
	/tmp/unlock/telneten 1 10
fi

killall stats
/tmp/unlock/stats
