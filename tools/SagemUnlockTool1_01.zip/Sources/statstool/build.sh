#!/bin/sh
mips-linux-gcc -v stats.c -o stats
